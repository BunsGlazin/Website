package com.thisWebsite.any;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnyApplicationTests {

	@Test
	void contextLoads() {
	}

}
