package com.thisWebsite.any.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.encrypt.BytesEncryptor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.thisWebsite.any.entities.loginEntity;
import com.thisWebsite.any.entities.newProductEntity;
import com.thisWebsite.any.entities.productInfoEntity;
import com.thisWebsite.any.entities.registerEntity;
import com.thisWebsite.any.repository.productInfoRepository;
import com.thisWebsite.any.servicer.loginService;
import com.thisWebsite.any.servicer.productService;
import com.thisWebsite.any.servicer.registrationService;

@RestController
@CrossOrigin("http://localhost:4200")
public class controller {
	
	@Autowired
	productInfoRepository pre;
	
	@Autowired
	registrationService registrationService;
	@Autowired
	productService productService;
	@Autowired
	loginService loginService;
	
	//createAccount
	@PostMapping("newAccount")
	public String createNewAccount(@RequestBody registerEntity account) {
		//System.out.println(account);
		return registrationService.createAccount(account);
	}
	
	//all product info
	@GetMapping("productInfo")
	public List<newProductEntity> getProductInfo() {
		return productService.getall();
	}
	
	//create new product put for admin side
	@PostMapping("newProduct")
	public String createNewProduct(@RequestBody newProductEntity product) {
		return productService.newProduct(product);
	}
	
	
	//login
	@PostMapping("loginVerify")
	public String login(@RequestBody loginEntity l) {
		return loginService.verifyLogin(l);
	}
	
	//logout
	@PutMapping("logout/{username}")
	public String loggerOut(@PathVariable String username) {
		return loginService.logout(username);
	}
	
	//check if anyone loggin in
	@GetMapping("checkLogin")
	public registerEntity checker() {
		return loginService.ifAnyoneLoggedIn();
	}
	
	
	@PutMapping("uploadImage/{id}")
	public String imager(@RequestParam("image") MultipartFile multipartFile, @PathVariable int id) throws IOException {
		String fileName = multipartFile.getName();)
        @SuppressWarnings("deprecation")
		productInfoEntity a = pre.getById(id);
        a.setImage(fileName);
        pre.save(a);
        System.out.println(multipartFile.getBytes());
        return "success";
	}
}
