package com.thisWebsite.any.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.thisWebsite.any.entities.loginEntity;
import com.thisWebsite.any.entities.productEntity;
import com.thisWebsite.any.entities.registerEntity;
import com.thisWebsite.any.servicer.loginService;
import com.thisWebsite.any.servicer.productService;
import com.thisWebsite.any.servicer.registrationService;

@RestController
@CrossOrigin("http://localhost:4200")
public class controller {
	
	@Autowired
	registrationService registrationService;
	@Autowired
	productService productService;
	@Autowired
	loginService loginService;
	
	
	@PostMapping("newAccount")
	public String createNewAccount(@RequestBody registerEntity account) {
		//System.out.println(account);
		return registrationService.createAccount(account);
	}
	
	@GetMapping("productInfo")
	public List<productEntity> getProductInfo() {
		return productService.getall();
	}
	
	@PostMapping("newProduct")
	public String createNewProduct(@RequestBody productEntity product) {
		return productService.newProduct(product);
	}
	
	@PostMapping("loginVerify")
	public String login(@RequestBody loginEntity l) {
		return loginService.verifyLogin(l);
	}
}
