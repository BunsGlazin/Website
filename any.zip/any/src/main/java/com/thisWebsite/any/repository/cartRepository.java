package com.thisWebsite.any.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.thisWebsite.any.entities.cartEntries;

@Repository
public interface cartRepository extends JpaRepository<cartEntries, Integer>{

	
	@Query("SELECT p FROM cartEntries p WHERE p.custUsername = :username")
	List<cartEntries> getEntriesOfCust(String username);
}
