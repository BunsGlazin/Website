package com.thisWebsite.any.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Cart")
public class cartEntries {

	@Id
	private int entryNo;
	private String custUsername;
	private int serverId;
	private String name;
	private String overview;
	private int price;
	private float rating;
	private String processor;
	private String ram;
	private String bandwidth;
	private int currentStock;
	private String image;

	public int getEntryNo() {
		return entryNo;
	}

	public void setEntryNo(int entryNo) {
		this.entryNo = entryNo;
	}

	public String getCustUsername() {
		return custUsername;
	}

	public void setCustUsername(String custUsername) {
		this.custUsername = custUsername;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public int getCurrentStock() {
		return currentStock;
	}

	public void setCurrentStock(int currentStock) {
		this.currentStock = currentStock;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	

	@Override
	public String toString() {
		return "cartEntries [entryNo=" + entryNo + ", custUsername=" + custUsername + ", serverId=" + serverId
				+ ", name=" + name + ", overview=" + overview + ", price=" + price + ", rating=" + rating
				+ ", processor=" + processor + ", ram=" + ram + ", bandwidth=" + bandwidth + ", currentStock="
				+ currentStock + ", image=" + image + "]";
	}
	
	

	public cartEntries(int entryNo, String custUsername, int serverId, String name, String overview, int price,
			float rating, String processor, String ram, String bandwidth, int currentStock, String image) {
		super();
		this.entryNo = entryNo;
		this.custUsername = custUsername;
		this.serverId = serverId;
		this.name = name;
		this.overview = overview;
		this.price = price;
		this.rating = rating;
		this.processor = processor;
		this.ram = ram;
		this.bandwidth = bandwidth;
		this.currentStock = currentStock;
		this.image = image;
	}

	private cartEntries() {

	}
}
