package com.thisWebsite.any.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "currentShowingProduct")
public class currentShowingProduct {
	
	@Id
	public int serverId;
	public String name;
	public String overview;
	public int price;
	public float rating;
	public String processor;
	public String ram;
	public String bandwidth;
	public int currentStock;
	public String image;
}
