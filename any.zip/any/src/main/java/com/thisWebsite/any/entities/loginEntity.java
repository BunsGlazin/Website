package com.thisWebsite.any.entities;

public class loginEntity {
	
	public String username;
	public String password;
}
