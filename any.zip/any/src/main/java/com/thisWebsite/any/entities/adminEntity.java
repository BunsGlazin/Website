package com.thisWebsite.any.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "admin")
public class adminEntity {
	
	@Id
	private String username;
	private String password;
	private boolean loginStatus = false;
	
	
	public adminEntity(String username, String password, boolean loginStatus) {
		super();
		this.username = username;
		this.password = password;
		this.loginStatus = loginStatus;
	}
	public boolean getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(boolean loginStatus) {
		this.loginStatus = loginStatus;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "adminEntity [username=" + username + ", password=" + password + ", loginStatus=" + loginStatus + "]";
	}
	public adminEntity(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	public adminEntity() {
		
	}
}
