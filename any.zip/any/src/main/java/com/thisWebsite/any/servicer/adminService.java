package com.thisWebsite.any.servicer;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thisWebsite.any.entities.adminEntity;
import com.thisWebsite.any.repository.adminRepository;

@Service
public class adminService {
	
	
	@Autowired
	adminRepository rep;
	
	public void newAdmin(adminEntity a) {
		rep.save(a);
	}
	
	public String checkLogin(adminEntity a) {
		Optional<adminEntity> check = rep.findById(a.getUsername());
		if(check.orElse(null)==null) {
			return "Invalid_Username";
		}
		else {
			@SuppressWarnings("deprecation")
			adminEntity b = rep.getById(a.getUsername());
			if(a.getPassword().equals(b.getPassword())) {
				b.setLoginStatus(true);
				rep.save(b);
				return "login";
			}
			else {
				return "Incorrect_Password";
			}
		}
	}
	
	public void logoutAdmin() {
		adminEntity adminEntity = rep.findAll().get(0);
		adminEntity.setLoginStatus(false);
		rep.save(adminEntity);
	}
	
	public adminEntity ifLoggedIn() {
		//System.out.println(rep.findAll().get(0));
		return rep.findAll().get(0).getLoginStatus() ? rep.findAll().get(0) : null;
	}
}
