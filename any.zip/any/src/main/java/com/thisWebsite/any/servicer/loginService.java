package com.thisWebsite.any.servicer;

import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.thisWebsite.any.entities.loginEntity;
import com.thisWebsite.any.entities.registerEntity;
import com.thisWebsite.any.repository.registerRepository;

@Service
public class loginService {
	
	
	@Autowired
	registerRepository registerRepository;
	
	public String verifyLogin(loginEntity log) {
		Optional<registerEntity> registerEntity = registerRepository.findById(log.username);
		
		
		if(registerEntity.orElse(null)==null) {
			return "Invalid_Username";
		}
		else {
			BCryptPasswordEncoder bc = new BCryptPasswordEncoder(8, new SecureRandom());
			@SuppressWarnings("deprecation")
			registerEntity reg = registerRepository.getById(log.username);
			if(bc.matches(log.password, reg.getPassword())) {
				reg.setLoggedIn(true);
				registerRepository.save(reg);
				return "login "+reg.getFirstName();
			}
			else {
				return "Incorrect_Password";
			}
		}
	}
	
	
	public String logout(String username) {
		@SuppressWarnings("deprecation")
		registerEntity reg = registerRepository.getById(username);
		reg.setLoggedIn(false);
		registerRepository.save(reg);
		return "logged_out";
	}
	
	
	public registerEntity ifAnyoneLoggedIn(){
		List<registerEntity> registerEntities = registerRepository.findAll();
		for(registerEntity i : registerEntities) {
			if(i.getLoggedIn()) {
				
				return i;
			}
		}
		return null;
	}
}
