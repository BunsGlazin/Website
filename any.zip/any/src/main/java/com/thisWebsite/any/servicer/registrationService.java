package com.thisWebsite.any.servicer;

import java.security.SecureRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.thisWebsite.any.entities.registerEntity;
import com.thisWebsite.any.repository.registerRepository;

@Service
public class registrationService {
	
	
	@Autowired
	registerRepository registerRepository;
	
	public String createAccount(registerEntity e) {
		
		BCryptPasswordEncoder bc = new BCryptPasswordEncoder(8, new SecureRandom());
		String pString = e.getPassword();
		//System.out.println(pString);
		e.setPassword(bc.encode(pString));
		registerRepository.save(e);
		return "success";
	}
}
