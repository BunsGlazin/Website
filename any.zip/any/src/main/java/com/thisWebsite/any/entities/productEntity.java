package com.thisWebsite.any.entities;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "servers")
public class productEntity {
	
	@Id
	private int serverId;
	private String name;
	private String overview;
	private int price;
	private float rating;
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOverview() {
		return overview;
	}
	public void setOverview(String overview) {
		this.overview = overview;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public productEntity(int serverId, String name, String overview, int price, float rating) {
		super();
		this.serverId = serverId;
		this.name = name;
		this.overview = overview;
		this.price = price;
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "productEntity [serverId=" + serverId + ", name=" + name + ", overview=" + overview + ", price=" + price
				+ ", rating=" + rating + "]";
	}
	public productEntity() {
		super();
	}
	
	
}
