package com.thisWebsite.any.servicer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thisWebsite.any.entities.productEntity;
import com.thisWebsite.any.repository.productRepository;

@Service
public class productService {
	
	@Autowired
	productRepository pRepository;
	
	public List<productEntity> getall() {
		return pRepository.findAll();
	}
	
	public String newProduct(productEntity p) {
		int newId = pRepository.findAll().size() + 1;
		p.setServerId(newId);
		pRepository.save(p);
		return "success";
	}
}
