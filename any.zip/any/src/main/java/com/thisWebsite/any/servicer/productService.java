package com.thisWebsite.any.servicer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thisWebsite.any.entities.newProductEntity;
import com.thisWebsite.any.entities.productEntity;
import com.thisWebsite.any.entities.productInfoEntity;
import com.thisWebsite.any.repository.productInfoRepository;
import com.thisWebsite.any.repository.productRepository;

@Service
public class productService {
	
	@Autowired
	productRepository pRepository;
	
	@Autowired
	productInfoRepository pRepo;
	
	public List<newProductEntity> getall() {
		List<productEntity> p = pRepository.findAll();
		List<productInfoEntity> e = pRepo.findAll();
		List<newProductEntity> l = new ArrayList<newProductEntity>();
		
		for(int i = 0; i<p.size(); i++) {
			l.add(new newProductEntity(p.get(i).getServerId(), p.get(i).getName(), p.get(i).getOverview(),
			p.get(i).getPrice(), p.get(i).getRating(), e.get(i).getProcessor(), e.get(i).getRam(), 
			e.get(i).getBandwidth(), e.get(i).getCurrentStock(), e.get(i).getImage()));
		}
		return l;
	}
	
	public String newProduct(newProductEntity p) {
		int newId = pRepository.findAll().size() + 1;
		productEntity pro = new productEntity(newId, p.name, p.overview, p.price, p.rating);
		pRepository.save(pro);
		productInfoEntity pro1 = new productInfoEntity(newId, p.processor, p.ram, p.bandwidth, p.currentStock);
		pRepo.save(pro1);
		return "success";
	}
}
