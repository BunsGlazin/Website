package com.thisWebsite.any.entities;

public class newProductEntity {
	
	public int serverId;
	public String name;
	public String overview;
	public int price;
	public float rating;
	public String processor;
	public String ram;
	public String bandwidth;
	public int currentStock;
	public String image;
	public newProductEntity(int serverId, String name, String overview, int price, float rating, String processor,
			String ram, String bandwidth, int currentStock, String image) {
		super();
		this.serverId = serverId;
		this.name = name;
		this.overview = overview;
		this.price = price;
		this.rating = rating;
		this.processor = processor;
		this.ram = ram;
		this.bandwidth = bandwidth;
		this.currentStock = currentStock;
		this.image = image;
	}
	
	
}
