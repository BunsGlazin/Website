package com.thisWebsite.any;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnyApplication.class, args);
	}

}
