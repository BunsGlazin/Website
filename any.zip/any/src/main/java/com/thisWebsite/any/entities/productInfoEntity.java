package com.thisWebsite.any.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "serverInfo")
public class productInfoEntity {
	
	@Id
	private int serverId;
	private String processor;
	private String ram;
	private String bandwidth;
	private int currentStock;
	
	private String image;
	
	
	
	public productInfoEntity(int serverId, String processor, String ram, String bandwidth, int currentStock,
			String image) {
		super();
		this.serverId = serverId;
		this.processor = processor;
		this.ram = ram;
		this.bandwidth = bandwidth;
		this.currentStock = currentStock;
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public String getProcessor() {
		return processor;
	}
	public void setProcessor(String processor) {
		this.processor = processor;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getBandwidth() {
		return bandwidth;
	}
	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}
	public int getCurrentStock() {
		return currentStock;
	}
	public void setCurrentStock(int currentStock) {
		this.currentStock = currentStock;
	}
	@Override
	public String toString() {
		return "productInfoEntity [serverId=" + serverId + ", processor=" + processor + ", ram=" + ram + ", bandwidth="
				+ bandwidth + ", currentStock=" + currentStock + ", image=" + image + "]";
	}
	
	public productInfoEntity() {}
	public productInfoEntity(int serverId, String processor, String ram, String bandwidth, int currentStock) {
		super();
		this.serverId = serverId;
		this.processor = processor;
		this.ram = ram;
		this.bandwidth = bandwidth;
		this.currentStock = currentStock;
	}
}
